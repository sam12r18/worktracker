<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller; use Illuminate\Http\Request; use Illuminate\Http\RedirectResponse; use Illuminate\Support\Facades\Auth; use Illuminate\View\View;
class LoginController extends Controller {
 public function create():View{return view('auth.login');}
 public function store(Request $request):RedirectResponse{$credentials=$request->validate(['email'=>['required','email'],'password'=>['required','string']]);if(!Auth::attempt($credentials,$request->boolean('remember'))){return back()->withErrors(['email'=>'ایمیل یا رمز عبور صحیح نیست.'])->onlyInput('email');}$request->session()->regenerate();return redirect()->intended(route('worktracker.dashboard'));}
 public function destroy(Request $request):RedirectResponse{Auth::logout();$request->session()->invalidate();$request->session()->regenerateToken();return redirect()->route('login');}
}
