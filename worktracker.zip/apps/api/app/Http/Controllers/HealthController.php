<?php
namespace App\Http\Controllers;
use Illuminate\Http\JsonResponse; use Illuminate\Support\Facades\{DB,Schema,Cache,Route};
class HealthController extends Controller {
 public function __invoke():JsonResponse{$checks=[];$ok=true;
  try{DB::select('select 1');$checks['database']=['status'=>'ok','driver'=>DB::connection()->getDriverName()];}catch(\Throwable $e){$ok=false;$checks['database']=['status'=>'fail','message'=>'database connection failed'];}
  $tables=['users','personal_access_tokens','devices','projects','activity_sessions','customers','activity_types','invoices','worktracker_audit_logs'];$missing=[];foreach($tables as $t){try{if(!Schema::hasTable($t))$missing[]=$t;}catch(\Throwable){$missing[]=$t;}}$checks['schema']=['status'=>$missing?'fail':'ok','missing'=>$missing];if($missing)$ok=false;
  $storage=is_dir(storage_path('framework'))&&is_writable(storage_path());$checks['storage']=['status'=>$storage?'ok':'fail'];if(!$storage)$ok=false;
  try{Cache::put('worktracker_health',time(),10);$cache=Cache::get('worktracker_health')!==null;}catch(\Throwable){$cache=false;}$checks['cache']=['status'=>$cache?'ok':'fail'];if(!$cache)$ok=false;
  $required=['login','worktracker.dashboard','worktracker.activities.index','worktracker.reports.index'];$missingRoutes=array_values(array_filter($required,fn($n)=>!Route::has($n)));$checks['routes']=['status'=>$missingRoutes?'fail':'ok','missing'=>$missingRoutes];if($missingRoutes)$ok=false;
  $checks['sanctum']=['status'=>class_exists(\Laravel\Sanctum\Sanctum::class)?'ok':'fail'];if($checks['sanctum']['status']!=='ok')$ok=false;
  return response()->json(['status'=>$ok?'ok':'fail','app'=>'WorkTracker','version'=>'0.1.0-alpha.7.2','environment'=>app()->environment(),'php'=>PHP_VERSION,'laravel'=>app()->version(),'checks'=>$checks,'time'=>now()->toIso8601String()],$ok?200:503);
 }
}
