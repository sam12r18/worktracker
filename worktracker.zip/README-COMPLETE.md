# WorkTracker 0.1.0-alpha.7.2 — Complete Package

## ساختار
- `server/` — Laravel 13 کامل و مستقل (نه overlay)
- `apps/windows-agent/WorkTracker.Agent/` — برنامه WPF ویندوز
- `tools/build-windows-agent.ps1` — Build ویندوز
- `docs/` — مستندات پروژه

## راه‌اندازی Laravel در Windows
```powershell
cd server
Copy-Item .env.example .env
# DB و WORKTRACKER_ADMIN_* را در .env تنظیم کنید
.\tools\setup-local.ps1
php artisan db:seed
php artisan serve
```

Health مستقیم: `http://127.0.0.1:8000/worktracker/health`
Login: `http://127.0.0.1:8000/login`
Dashboard: `http://127.0.0.1:8000/worktracker`

## Build ویندوز
```powershell
.\tools\build-windows-agent.ps1
```

## cPanel
کل پوشه `server/` اپلیکیشن Laravel است. DocumentRoot دامنه/ساب‌دامین باید به `server/public` اشاره کند. در production: `APP_DEBUG=false` و `WORKTRACKER_REQUIRE_HTTPS=true`.
